Vue.component("greeting",{
	template:'<p>{{name}}大家好，hello world！！！<button v-on:click="changename">改名</button></p>',
	data:function(){
		return{
			name:"javascript"
		}
	},
	methods:{
		changename:function(){
			this.name="henry";
		}
	}
})


// 实例化vue对象
var one=new Vue({
	el: "#vue-app-one", 
	
 });


var two=new Vue({
	el: "#vue-app-two", 
	
 });


/**
 * 
 * 
 */